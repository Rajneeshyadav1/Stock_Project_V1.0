package com.example.demo.model;



public class Email {
	
	private String to;
	private String messageSubject;
	private String body;
	private int code;
	
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code=code;
	}
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}
	public String getMessageSubject() {
		return messageSubject;
	}
	public void setMessageSubject(String messageSubject) {
		this.messageSubject = messageSubject;
		
	}
		
	public String getBody() {
		return body+code;
	}
	public void setBody(String body) {
		this.body = body;
	}
	
	
	
}
