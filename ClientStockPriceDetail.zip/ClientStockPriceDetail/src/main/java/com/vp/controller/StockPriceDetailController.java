package com.vp.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.vp.model.StockPriceDetail;
import com.vp.model.Summary;
import com.vp.service.StockPriceDetailService;

@RestController
@CrossOrigin(origins = "http://localhost:4200", maxAge = 3600)
public class StockPriceDetailController {
	
	@Autowired
	StockPriceDetailService stockPriceDetailService;
	
	@Autowired
	Summary summary;
	
	 private LocalDate toDate;
	 private LocalDate fromDate;
	 private int noOfRecord;
	 private String stockExchange;
	 Summary all;
	
	@PostMapping("/import")
	public void mapReapExcelDatatoDB(@RequestParam("file") MultipartFile reapExcelDataFile) throws IOException {

	    List<StockPriceDetail> tempStockData = new ArrayList<StockPriceDetail>();
	    XSSFWorkbook workbook = new XSSFWorkbook(reapExcelDataFile.getInputStream());
	    XSSFSheet worksheet = workbook.getSheetAt(0);

	    for(int i=1;i<worksheet.getPhysicalNumberOfRows() ;i++) {
	    	StockPriceDetail stockPriceDetail = new StockPriceDetail();

	        XSSFRow row = worksheet.getRow(i);

	        //StockPriceDetail.setSid((long) row.getCell(0).getNumericCellValue());
	        String stockExchangeCode = row != null ? row.getCell(0).getStringCellValue() : null;
	        if(null == stockExchangeCode || stockExchangeCode.isEmpty())
	        	break;
	        
	        stockPriceDetail.setCompany_code(stockExchangeCode);
	        stockPriceDetail.setStock_exchange(row.getCell(1).getStringCellValue());
	        stockPriceDetail.setCurrent_price(row.getCell(2).getNumericCellValue());
	        
	        LocalDate localDate = row.getCell(3).getDateCellValue().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
	        stockPriceDetail.setDate(localDate);
	        
	        String tim = row.getCell(4).getStringCellValue();	                	       
	       // SimpleDateFormat simpleDateFormat = new SimpleDateFormat("HH:mm:ss");
	        LocalTime time = LocalTime.parse(tim.trim());	        
	        stockPriceDetail.setTime(time);
	        
	        System.out.println("STOCK DATA : "+stockPriceDetail);
	        
	        tempStockData.add(stockPriceDetail);   
	        
	        stockPriceDetailService.saveStockPriceDetail(stockPriceDetail);
	        System.out.println("Done StockPriceDetail Saved");
	        
	        if(i==1){
	        	fromDate=localDate;
	        }
	        else{
	        	toDate=localDate;
	        } 
	        noOfRecord=i;
	        stockExchange=row.getCell(1).getStringCellValue();       
	    }
	    Summary summary = new Summary();
	    summary.setToDate(toDate);
	    summary.setFromDate(fromDate);
	    summary.setNoOfRecord(noOfRecord);
	    summary.setStockExchange(stockExchange);
	    all=summary;
	}
	
	@GetMapping("/info")
	public Summary info() {
		return all;
	}
	
	@GetMapping("/stockPriceDetail")
	public List<StockPriceDetail> getAllStockData(){
		return stockPriceDetailService.getAllStockPriceDetail();
	}
}