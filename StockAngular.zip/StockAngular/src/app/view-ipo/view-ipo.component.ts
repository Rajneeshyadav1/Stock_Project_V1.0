import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { UpdateIpoModel } from "src/app/update-ipo/UpdateIpoModel";
import { UpdateIpoService } from 'src/app/update-ipo/update-ipo.service';


@Component({
  selector: 'app-view-ipo',
  templateUrl: './view-ipo.component.html',
  styleUrls: ['./view-ipo.component.css']
})
export class ViewIpoComponent implements OnInit {

  constructor(private router: Router,private service:UpdateIpoService) { }
  myForm4: FormGroup;
  ipoDetails:UpdateIpoModel[];
  ipo:UpdateIpoModel;

  ngOnInit(): void {
    this.service.getAllIpoDetails().subscribe(data => {
      this.ipoDetails = data.body;
      console.log(data.body)
 });
    {
      this.myForm4 = new FormGroup({
        name: new FormControl(''),
        
      });
  }
}
  onSubmit4(form: FormGroup){
  }
  
  title = 'SPB-Test3';
}

