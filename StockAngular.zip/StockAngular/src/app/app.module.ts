import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { ChartsModule } from 'ng2-charts';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginPageComponent } from './login-page/login-page.component';
import { SignupPageComponent } from './signup-page/signup-page.component';
import { AdminPageComponent } from './admin-page/admin-page.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { LoginPageService } from 'src/app/login-page/login-page.service';
import { UserPageComponent } from './user-page/user-page.component';
import { SignupPageService } from 'src/app/signup-page/signup-page.service';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { CompanyDetailsComponent } from './company-details/company-details.component';
import { CompanyCreateComponent } from './company-create/company-create.component'; 
import { CompanyDetailsService } from 'src/app/company-details/company-details.service';
import { CompanyUpdateComponent } from './company-update/company-update.component';
import { ImportDataComponent } from './import-data/import-data.component';
import { ImportExcelService } from 'src/app/import-data/import-excel.service';
import { UpdateIpoComponent } from './update-ipo/update-ipo.component';
import { UpdateIpoService } from 'src/app/update-ipo/update-ipo.service';
import { IpoDetalisComponent } from './ipo-detalis/ipo-detalis.component';
import { ViewIpoComponent } from './view-ipo/view-ipo.component';
import { MailVerifyComponent } from './mail-verify/mail-verify.component';
import { MailVerifyService } from 'src/app/mail-verify/mail-verify.service';
import { ManageExchangeComponent } from './manage-exchange/manage-exchange.component';
import { ManageExchangeService } from 'src/app/manage-exchange/manage-exchange.service';
import { BarChartComponent } from './bar-chart/bar-chart.component';
import { from } from 'rxjs';


@NgModule({
  declarations: [
    AppComponent,
    LoginPageComponent,
    SignupPageComponent,
    AdminPageComponent,
    UserPageComponent,
    UserProfileComponent,
    CompanyDetailsComponent,
    CompanyCreateComponent,
    CompanyUpdateComponent,
    ImportDataComponent,
    UpdateIpoComponent,
    IpoDetalisComponent,
    ViewIpoComponent,
    MailVerifyComponent,
    ManageExchangeComponent,
    BarChartComponent
    
    
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    AppRoutingModule,
    HttpClientModule,
    ChartsModule
  ],
  providers: [LoginPageService,SignupPageService,CompanyDetailsService,ImportExcelService,UpdateIpoService,MailVerifyService,ManageExchangeService],
  bootstrap: [AppComponent]
})

export class AppModule {}
