import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { CompanyDetailsModel } from 'src/app/company-details/CompanyDetailsModel';

type EntityResponseType = HttpResponse<CompanyDetailsModel[]>;

@Injectable({
  providedIn: 'root'
})
export class CompanyDetailsService {  

  constructor(private http:HttpClient) { }

  getAllCompanyDetails():Observable<EntityResponseType>{
        return this.http.get<CompanyDetailsModel[]>("http://localhost:5511/companyDetails", {observe: 'response'});
  }

  saveCompanyDetails(companyDetailsModel:CompanyDetailsModel){
       return this.http.post<CompanyDetailsModel>("http://localhost:5511/companyDetail", companyDetailsModel, {observe: 'response'});
  }
  
  

}