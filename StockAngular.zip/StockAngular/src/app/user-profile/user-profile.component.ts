import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { SignupPageService } from 'src/app/signup-page/signup-page.service';
import { loginPageModel } from 'src/app/login-page/loginPageModel';
import { Template } from '@angular/compiler/src/render3/r3_ast';


@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
  
})
export class UserProfileComponent implements OnInit {
 // qwe: string;


  constructor(private service:SignupPageService,private router: Router) { }
  myForm5: FormGroup;
  userDetails3:loginPageModel[];
  wer:any;

  ngOnInit(): void {
    {
      this.myForm5 = new FormGroup({
        name: new FormControl(''),
        mob: new FormControl(''),
        pwd: new FormControl('')
      });
  }
  
   let qwe:string = window.localStorage.getItem('item1');
      this.wer = JSON.parse(qwe);

  }

  onSubmit5(form: FormGroup){
    let userDetails3:loginPageModel = this.wer;
    
    /* if(form.value.name!=null){userDetails3.username=form.value.name;alert("Name updated");}
     if(form.value.mob!=null){userDetails3.mobile_number=form.value.mob;alert("Mob no update");}
     if(form.value.pwd!=null){userDetails3.password=form.value.pwd;alert("Password updated");}*/

     let x:string = form.value.name;
     let y:string = form.value.pwd;
     let z:string = form.value.mob;

     if(form.value.name==0){x=userDetails3.username;}
     if(form.value.pwd==0){y=userDetails3.password;}
     if(form.value.mob==0){z=userDetails3.mobile_number;}

     let userDetails4:loginPageModel = {
      id:userDetails3.id,
      username:x,
      password:y,
      usertype:userDetails3.usertype,
      email:userDetails3.email,
      mobile_number:z,
      confirmation:userDetails3.confirmation
    }

    this.service.saveUserDetails(userDetails4).subscribe(data =>{
      console.log(userDetails4);
   });
   window.localStorage.clear();
   window.localStorage.setItem("item1",JSON.stringify(userDetails4));

    alert("Details Updated");
  }
  title = 'SPB-Test3';
}

