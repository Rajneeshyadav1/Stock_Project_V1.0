import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-page',
  templateUrl: './admin-page.component.html',
  styleUrls: ['./admin-page.component.css']
})
export class AdminPageComponent implements OnInit {

  constructor(private router: Router) { }
  myForm3: FormGroup;

  ngOnInit(): void {
    {
      this.myForm3 = new FormGroup({
        name: new FormControl(''),
        
      });
  }
}
  onSubmit3(form: FormGroup){
  }
  title = 'SPB-Test3';
}

