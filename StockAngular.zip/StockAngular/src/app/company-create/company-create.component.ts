import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { CompanyDetailsModel } from 'src/app/company-details/CompanyDetailsModel';
import { CompanyDetailsService } from 'src/app/company-details/company-details.service';
import { UpdateIpoModel } from "src/app/update-ipo/UpdateIpoModel";
import { UpdateIpoService } from 'src/app/update-ipo/update-ipo.service';


@Component({
  selector: 'app-company-create',
  templateUrl: './company-create.component.html',
  styleUrls: ['./company-create.component.css']
})
export class CompanyCreateComponent implements OnInit {

  constructor(private router: Router,private service:CompanyDetailsService,private service2:UpdateIpoService) { }
  myForm5: FormGroup;
  companyDetails2:CompanyDetailsModel[];
  updateIpo:UpdateIpoModel[];

  ngOnInit(): void {
    this.service.getAllCompanyDetails().subscribe(data => {
      this.companyDetails2 = data.body;
      console.log(data.body)
 });
 this.service2.getAllIpoDetails().subscribe(data => {
  this.updateIpo = data.body;
  console.log(data.body)
});
    {
      this.myForm5 = new FormGroup({
        cname: new FormControl(''),
        ceo: new FormControl(''),
        bod: new FormControl(''),
        tover: new FormControl(''),
        desc: new FormControl(''),
        sname: new FormControl(''),
        sector: new FormControl(''),
        scode: new FormControl(''),
        ipodate: new FormControl('')
      });
  }
}
  onSubmit5(form: FormGroup){
    let companyDetails:CompanyDetailsModel = {
      company_name:form.value.cname,
  turnover:form.value.tover,
  ceo:form.value.ceo,
  board_of_directors:form.value.bod,
  listed_in_stock_exchange:form.value.sname,
  sector:form.value.sector,
  brief_about_companies:form.value.desc,
  stock_code_in_each_stock_exchange:form.value.scode
        
    };
    let ipoDetails:UpdateIpoModel ={
      company_name:form.value.cname,
    stock_exchange:'',
    price_per_share:null,
    total_number_of_shares:'',                        
    open_date_time:form.value.ipodate,
    remarks:''
    }

    this.service.saveCompanyDetails(companyDetails).subscribe(data =>{
       console.log(data.body);
    });
    this.service2.saveIpoDetails(ipoDetails).subscribe(data =>{
      console.log(data.body);
   });
  }
  title = 'SPB-Test3';
}


