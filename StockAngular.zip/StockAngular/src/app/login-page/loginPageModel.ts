export interface loginPageModel{
    id:String;
    username:string;
    password:string;
    usertype:string;
    email:string;
    mobile_number:string;
    confirmation:string
}