import { Component, OnInit, Output, EventEmitter} from '@angular/core';
import { loginPageModel } from "src/app/login-page/loginPageModel";
import { LoginPageService } from 'src/app/login-page/login-page.service';
import { FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { element } from 'protractor';


@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.css']
})
export class LoginPageComponent implements OnInit {

 // @Output() notify: EventEmitter<Number> = new EventEmitter<Number>();

  userDetails:loginPageModel[];
  myForm: FormGroup;
  //item1: loginPageModel[];
  
  constructor(private service:LoginPageService,private router: Router) { }

  ngOnInit(): void {
    this.service.getAllUserDetails().subscribe(data => {
      this.userDetails = data.body;
      console.log(data.body) 
 });



 {
  this.myForm = new FormGroup({
    name: new FormControl(''),
    action: new FormControl('')
  });
}
  } 

  /*onSubmit(form: FormGroup){
    var k=0;
    for(var i=1;i<this.userDetails.length;i++){
      if(this.userDetails[i].username==form.value.name &&
        this.userDetails[i].password==form.value.action &&
        this.userDetails[i].usertype=="user" &&
        this.userDetails[i].confirmation=="confirmed"){k=1;this.router.navigate(['/app-signup-page']);}
    }
  if(k==0){
    
  if(this.userDetails[0].username==form.value.name &&
     this.userDetails[0].password==form.value.action &&
     this.userDetails[0].usertype=="admin" &&
     this.userDetails[0].confirmation=="confirmed"){this.router.navigate(['/app-admin-page']);}
     else{alert("Incorrect Username Or Password");}
  }
}*/

onSubmit(form: FormGroup){
  var k=0;
  
  for(var i=0;i<this.userDetails.length;i++){
    if(this.userDetails[i].username==form.value.name &&
       this.userDetails[i].password==form.value.action &&
       this.userDetails[i].confirmation=="confirmed"){
          k=1;
        if(this.userDetails[i].usertype=="admin"){this.router.navigate(['/app-admin-page']);break;}
        if(this.userDetails[i].usertype=="user"){window.localStorage.setItem("item1",JSON.stringify(this.userDetails[i]));this.router.navigate(['/app-user-page']);break;}
        }
       
}
if(k==0){alert("Incorrect Username Or Password");}

//console.log();
}
  title = 'SPB-Test3';
}
