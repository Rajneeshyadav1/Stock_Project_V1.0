import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { loginPageModel } from "src/app/login-page/loginPageModel";

type EntityResponseType = HttpResponse<loginPageModel[]>;

@Injectable({
  providedIn: 'root'
})

export class LoginPageService {  

  constructor(private http:HttpClient) { }

  getAllUserDetails():Observable<EntityResponseType>{
        return this.http.get<loginPageModel[]>("http://localhost:5515/UserDatabases", {observe: 'response'});
  }

}