import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginPageComponent } from './login-page/login-page.component';
import { SignupPageComponent } from './signup-page/signup-page.component';
import { AdminPageComponent } from './admin-page/admin-page.component';
import { UserPageComponent } from './user-page/user-page.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { CompanyDetailsComponent } from './company-details/company-details.component'; 
import { CompanyCreateComponent } from './company-create/company-create.component'; 
import { CompanyUpdateComponent } from './company-update/company-update.component';
import { ImportDataComponent } from './import-data/import-data.component';
import { UpdateIpoComponent } from './update-ipo/update-ipo.component';
import { IpoDetalisComponent } from './ipo-detalis/ipo-detalis.component';
import { ViewIpoComponent } from './view-ipo/view-ipo.component';
import { MailVerifyComponent } from './mail-verify/mail-verify.component';
import { ManageExchangeComponent } from './manage-exchange/manage-exchange.component';
import { BarChartComponent } from './bar-chart/bar-chart.component';


const routes: Routes = [{path:'',redirectTo:'app-login-page',pathMatch:'full'},
                        {path:'app-login-page',component:LoginPageComponent},
                        {path:'app-signup-page',component:SignupPageComponent},
                        {path:'app-admin-page',component:AdminPageComponent},
                        {path:'app-user-page',component:UserPageComponent},
                        {path:'app-user-profile',component:UserProfileComponent},
                        {path:'app-company-details',component:CompanyDetailsComponent},
                        {path:'app-company-create',component:CompanyCreateComponent},
                        {path:'app-company-update',component:CompanyUpdateComponent},
                        {path:'app-import-data',component:ImportDataComponent},
                        {path:'app-update-ipo',component:UpdateIpoComponent},
                        {path:'app-ipo-detalis',component:IpoDetalisComponent},
                        {path:'app-view-ipo',component:ViewIpoComponent},
                        {path:'app-mail-verify',component:MailVerifyComponent},
                        {path:'app-manage-exchange',component:ManageExchangeComponent},
                        {path:'app-bar-chart',component:BarChartComponent}];

                        
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
