import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bar-chart',
  templateUrl: './bar-chart.component.html',
  styleUrls: ['./bar-chart.component.css']
})
export class BarChartComponent implements OnInit {
  public barChartOptions = {
    scaleShowVerticalsLines: false,
    responsive: true
  };
  public barChartLabels = ['1000','2000','3000','4000','5000','6000','7000'];
  public barChartType = 'bar';
  public barChartLegend = 'true';
  public barChartData = [
    {data: [1500, 2300, 4500, 5400, 1200, 1500, 4000], label: 'Company A'},
    {data: [2500, 790, 4000, 6100, 2600, 5400, 1000], label: 'Cpmpany B'}
  ]
  ngOnInit(): void {
  }

}
