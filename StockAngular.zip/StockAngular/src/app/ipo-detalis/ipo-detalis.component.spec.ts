import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IpoDetalisComponent } from './ipo-detalis.component';

describe('IpoDetalisComponent', () => {
  let component: IpoDetalisComponent;
  let fixture: ComponentFixture<IpoDetalisComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IpoDetalisComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IpoDetalisComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
