import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { UpdateIpoModel } from "src/app/update-ipo/UpdateIpoModel";

type EntityResponseType = HttpResponse<UpdateIpoModel[]>;

@Injectable({
  providedIn: 'root'
})

export class UpdateIpoService {  

  constructor(private http:HttpClient) { }

  getAllIpoDetails():Observable<EntityResponseType>{
        return this.http.get<UpdateIpoModel[]>("http://localhost:5513/ipoPlannedd", {observe: 'response'});
  }

  saveIpoDetails(UpdateIpoModeln:UpdateIpoModel){
    return this.http.post<UpdateIpoModel>("http://localhost:5513/ipoPlanned", UpdateIpoModeln, {observe: 'response'});
}

}