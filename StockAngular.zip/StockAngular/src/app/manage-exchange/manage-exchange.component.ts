import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { ManageExchangeService } from './manage-exchange.service';
import { ManageExchangeModel } from './ManageExchangeModel';


@Component({
  selector: 'app-manage-exchange',
  templateUrl: './manage-exchange.component.html',
  styleUrls: ['./manage-exchange.component.css']
})
export class ManageExchangeComponent implements OnInit {

  constructor(private router: Router,private service:ManageExchangeService) { }
  myForm4: FormGroup;
  excDetails:ManageExchangeModel[];
  exc:ManageExchangeModel;

  ngOnInit(): void {
    this.service.getAllExchange().subscribe(data => {
      this.excDetails = data.body;
      console.log(data.body)
 });
    {
      this.myForm4 = new FormGroup({
        name: new FormControl(''),
        
      });
  }
}
  onSubmit4(form: FormGroup){
  }
  
  title = 'SPB-Test3';
}
