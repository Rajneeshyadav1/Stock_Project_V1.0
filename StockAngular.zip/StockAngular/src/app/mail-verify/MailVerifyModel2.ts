export interface MailVerifyModel2{
    email:string;
}