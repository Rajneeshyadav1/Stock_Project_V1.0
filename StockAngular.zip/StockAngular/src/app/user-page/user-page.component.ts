import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { CompanyDetailsService } from '../company-details/company-details.service';
import { CompanyDetailsModel } from 'src/app/company-details/CompanyDetailsModel';

@Component({
  selector: 'app-user-page',
  templateUrl: './user-page.component.html',
  styleUrls: ['./user-page.component.css']
})
export class UserPageComponent implements OnInit {


   userData:CompanyDetailsModel[];

  userList1: any;

   lastkeydown1: number = 0;
   subscription: any;

   constructor(private router: Router, private companydetails:CompanyDetailsService) { }  

  
  myForm4: FormGroup;
 
  ngOnInit(): void {
    this.companydetails.getAllCompanyDetails().subscribe(data => {
      this.userData = data.body;
      console.log(data.body) 
 });
    {
      this.myForm4 = new FormGroup({
        name: new FormControl(''),
        
      });
  }
}
getUserIdsFirstWay($event) {
  let userId = (<HTMLInputElement>document.getElementById('userIdFirstWay')).value;
  this.userList1 = [];

  if (userId.length > 0) {
    if ($event.timeStamp - this.lastkeydown1 > 200) {
      this.userList1 = this.searchFromArray(this.userData, userId);
    }
  }}
  searchFromArray(arr, regex) {
    let matches = [], i;
    for (i = 0; i < arr.length; i++) {
      if (arr[i].company_name.match(regex)) {
        matches.push(arr[i].company_name);
      }
    }
    return matches;
  };
  onSubmit4(form: FormGroup){
    
  }
  title = 'SPB-Test3';






}
