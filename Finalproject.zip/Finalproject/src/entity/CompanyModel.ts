export interface CompanyModel{
    id?:number;
    company_name:string;
    turnover:number;
    ceo:string;
    board:string;
    listed:string;
    sector:string;
    writeup:string;
    stckcode:number;
}