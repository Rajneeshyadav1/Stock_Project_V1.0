export interface UserModel{
    uid?:number;
    username:string;
    password:string;
    type?:string;
    email:string;
    mobile:number;
    confirmed?:boolean;
}