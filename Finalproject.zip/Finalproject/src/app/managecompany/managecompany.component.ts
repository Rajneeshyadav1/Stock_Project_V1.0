import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { CompanyModel } from 'src/entity/CompanyModel';
import { Router } from '@angular/router';
import { CompanyService } from '../service/company.service';

@Component({
  selector: 'app-managecompany',
  templateUrl: './managecompany.component.html',
  styleUrls: ['./managecompany.component.css']
})
export class ManagecompanyComponent implements OnInit {
  myForm2: FormGroup;
  company:CompanyModel[];
  use:any;
  
  constructor(private router:Router,private service:CompanyService) { }

 
  ngOnInit(): void {
    this.service.getAllCompany().subscribe(data => {
         this.company = data.body;
         console.log(data.body)
    });
  }
  ons(){
    this.router.navigate(['/']);
  }
  createcompany(){
    this.router.navigate(['/createcompany']);
  
  }
  updateCompany(id: number){
    

    this.router.navigate(['/update']);
  }
  deleteCompany(id):void{
    console.log(id);
    this.service.deleteCompany(id).subscribe(data=>
      this.use=data);
  }

}
