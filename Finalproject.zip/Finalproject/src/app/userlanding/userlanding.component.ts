import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userlanding',
  templateUrl: './userlanding.component.html',
  styleUrls: ['./userlanding.component.css']
})
export class UserlandingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
