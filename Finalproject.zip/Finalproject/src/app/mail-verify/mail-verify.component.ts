import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { MailVerifyService } from 'src/app/mail-verify/mail-verify.service';
import { MailVerifyModel } from './MailVerifyModel';
import { SignupPageService } from 'src/app/signup-page/signup-page.service';

@Component({
  selector: 'app-mail-verify',
  templateUrl: './mail-verify.component.html',
  styleUrls: ['./mail-verify.component.css']
})
export class MailVerifyComponent implements OnInit {

  constructor(private router: Router,private service:SignupPageService,private service2:MailVerifyService) { }
  myForm: FormGroup;
  newCode:MailVerifyModel[];
  
  verCode:string;
  locStor:any;

  ngOnInit(): void {
    this.service2.getCode().subscribe(data => {
      this.newCode = data.body;
      
      console.log(data.body)
 });
    {
      this.myForm = new FormGroup({
        code1: new FormControl(''),
        
      });
  }
}
  onSubmit2(form: FormGroup){
    if(this.newCode==form.value.code1){
      var kuchbhi = window.localStorage.getItem('item4');
      let locStor = JSON.parse(kuchbhi);

      this.service.saveUserDetails(locStor).subscribe(data =>{
        console.log(data.body);
       });
       alert("Email Verification Successful");
    }
    else{
      alert("wrong code detected");
    }
  }
  title = 'SPB-Test3';
}
