import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { MailVerifyModel } from './MailVerifyModel';
import { MailVerifyModel2 } from '../mail-verify/MailVerifyModel2';

  type EntityResponseType = HttpResponse<MailVerifyModel[]>;
//type EntityResponseType = HttpResponse<string>;

@Injectable({
  providedIn: 'root'
})
export class MailVerifyService {  

  constructor(private http:HttpClient) { }

  getCode():Observable<EntityResponseType>{
         return this.http.get<MailVerifyModel[]>("http://localhost:0725/email/sendmail", {observe: 'response'});
       // return this.http.get<string>("http://localhost:0725/email/sendmail",{observe: 'response'});
  }

  saveEmail(mailVerifyModel:MailVerifyModel2){
       return this.http.post<MailVerifyModel2>("http://localhost:0725/email/mail", mailVerifyModel, {observe: 'response'});
  }

  compare(){
    return this.http.get<MailVerifyModel>("http://localhost:0725/compare",{observe: 'response'});
  }
  

}