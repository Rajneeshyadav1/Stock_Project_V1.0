import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { CompanyModel } from 'src/entity/CompanyModel';
import { UpdateIpoModel } from './UpdateIpoModel';

type EntityResponseType1 = HttpResponse<UpdateIpoModel[]>;


@Injectable({
  providedIn: 'root'
})
export class UpdateIPOService {

  constructor(private http:HttpClient) { }
  getAllIpoDetails():Observable<EntityResponseType1>{
    //return this.http.get<StudentModel[]>("http://localhost:8084/students", {observe: 'response'});
    return this.http.get<UpdateIpoModel[]>("http://localhost:9003/ipos", {observe: 'response'});
  }
  
}
