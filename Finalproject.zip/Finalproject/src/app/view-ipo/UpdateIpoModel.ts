export interface UpdateIpoModel{
    ID?:number;
    company_name:string
    stock_id:string;
    price_per_share:number;
    no_of_shares:string;
    remarks:string

}