import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';

import { UserModel } from 'src/entity/UserModel';

type EntityResponseType = HttpResponse<UserModel[]>;

@Injectable({
  providedIn: 'root'
})

export class SignupPageService {  

  constructor(private http:HttpClient) { }

  getAllUserDetails():Observable<EntityResponseType>{
        return this.http.get<UserModel[]>("http://localhost:0725/email/sendmail", {observe: 'response'});
  }

  saveUserDetails(UserModeln:UserModel){
    return this.http.post<UserModel>("http://localhost:0725/email/mail", UserModeln, {observe: 'response'});
}

}