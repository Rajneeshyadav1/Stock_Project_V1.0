import { TestBed } from '@angular/core/testing';

import { SignupPageService } from './signup-page.service';

describe('SignupPageService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SignupPageService = TestBed.get(SignupPageService);
    expect(service).toBeTruthy();
  });
});
