import { Component, OnInit } from '@angular/core';
import { RouterModule, Router } from '@angular/router';
import { FormGroup, FormControl } from '@angular/forms';

import { UserModel } from 'src/entity/UserModel';
import { SignupPageService } from 'src/app/signup-page/signup-page.service';
import { MailVerifyService } from 'src/app/mail-verify/mail-verify.service';


import { MailVerifyModel } from '../mail-verify/MailVerifyModel';
import { MailVerifyModel2 } from '../mail-verify/MailVerifyModel2';

@Component({
  selector: 'app-signup-page',
  templateUrl: './signup-page.component.html',
  styleUrls: ['./signup-page.component.css']
})
export class SignupPageComponent implements OnInit {

  myForm2: FormGroup;
  userDetails2:UserModel[];
  sendEmail:MailVerifyModel2[];

  constructor(private service:SignupPageService,private router: Router,private service2:MailVerifyService) { }
  
  ngOnInit(): void {
          this.myForm2 = new FormGroup({
        name: new FormControl(''),
        mob: new FormControl(''),
        eid: new FormControl(''),
        pwd: new FormControl('')
        
      });

      this.service.getAllUserDetails().subscribe(data => {
        this.userDetails2 = data.body;
        console.log(data.body) 
   });

      

      }
      onSubmit(form: FormGroup){
        var x = (form.value.name+form.value.pwd);
        let userDetails2:UserModel = {
          uid:x,
          username:form.value.name,
          password:form.value.pwd,
          type:'user',
          email:form.value.eid,
          mobile:form.value.mob,
          confirmed:true
        }

        let sendEmail2:MailVerifyModel2={
          email:form.value.eid
        }

        window.localStorage.setItem('item4',JSON.stringify(userDetails2));
        
        
         this.service2.saveEmail(sendEmail2).subscribe(data =>{
           console.log(data.body);
           console.log(sendEmail2);
        });

        this.router.navigate(['/app-mail-verify']);
      }
  title = 'SPB-Test3';
}

