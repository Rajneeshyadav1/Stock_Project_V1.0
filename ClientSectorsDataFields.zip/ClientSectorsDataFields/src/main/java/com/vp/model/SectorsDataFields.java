package com.vp.model;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "sectors_data_fields")
public class SectorsDataFields {
	@Id
	private String id;
	private String sector_name;
	private String brief;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getSector_name() {
		return sector_name;
	}
	public void setSector_name(String sector_name) {
		this.sector_name = sector_name;
	}
	public String getBrief() {
		return brief;
	}
	public void setBrief(String brief) {
		this.brief = brief;
	}
	public SectorsDataFields(String id, String sector_name, String brief) {
		super();
		this.id = id;
		this.sector_name = sector_name;
		this.brief = brief;
	}
	public SectorsDataFields() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "ClientSectorsDataFields [id=" + id + ", sector_name=" + sector_name + ", brief=" + brief + "]";
	}
	
	
}
