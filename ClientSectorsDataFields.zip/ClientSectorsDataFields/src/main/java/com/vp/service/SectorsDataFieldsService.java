package com.vp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.vp.model.SectorsDataFields;
import com.vp.repository.SectorsDataFieldsRepository;

@Service
@Transactional
public class SectorsDataFieldsService {
    
	@Autowired
	SectorsDataFieldsRepository sectorsDataFieldsRepository;
	
	public List<SectorsDataFields> getAllSectorsDataFields(){
		return (List<SectorsDataFields>) sectorsDataFieldsRepository.findAll();
	}
	
	public void saveSectorsDataFields(SectorsDataFields sectorsDataFields) {
		sectorsDataFieldsRepository.save(sectorsDataFields);
	}
	
}