package com.vp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClientUserDatabaseApplicationTests {

	@Test
	void contextLoads() {
	}
//	 @Test
//   public void getAllEmployeesTest()
//   {
//       List<UserDatabse> list = new ArrayList<EmployeeVO>();
//       UserDatabse empOne = new UserDatabse(1, "shubham", 'shub@');
//       UserDatabse empTwo = new UserDatabse(2, "pratyush", 'shub123');
//       UserDatabse empThree = new UserDatabse(3, "Steve", 4333333);
//       
//       list.add(empOne);
//       list.add(empTwo);
//       list.add(empThree);

//test
//   List<UserDatabse> empList = manager.getUserDatabse();
//   
//   System.out.println("dao.getUserDatabse -TEST :"+empList);
//   
//   assertEquals(3, empList.size());
//   verify(dao, times(1)).getUserDatabse();

//}
}


